import './App.css'
import pokemon from './components/paginas/pokemon';


function App() {

  return (
    <div className="App">
      <Router>
        <Navbar/>
        <switch>
          <Router path='/pokemon' component={Pokemon}/>
        </switch>
      </Router>
    </div>
  );
}

export default App;
  