import React from 'react'
import {Link} from 'react-router-dom'


const Footer=()=>{

    return(
        <div>
            <Footer className= 'text-white py-4 bg-dark'
            <div className='container'>
                <nav className='row'>
                    <link to='/' className='col-12 col-md3 d-flex aling-items-center justyfy-content-cente'>
                        
                    </link>
                </nav>
            </div>
        </div>
    )
}
