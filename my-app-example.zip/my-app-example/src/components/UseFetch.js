import React , {useState,useEffect}from 'react'

export const UseFetch = (URL) => {
    const [resultado,setResultado]=useState({cargando:true,data:null})

    useEffect( ()=>{
        getDatos(URL)
    },[URL])

    async function getDatos(URL){
        try{
        setResultado({cargando:true,data:null})
        const resp=await fetch(URL)
        const data=await resp.json()
        setResultado({cargando:false,data})
        }
        catch (e){
            console.log(e)
        }

    }

    return resultado
     (
        <did>

        </did>
    )
}
